
public class Add1 {

	public static void main(String[] args) {
		int x = 11;
		x++;
		System.out.println(x);
	}

}
