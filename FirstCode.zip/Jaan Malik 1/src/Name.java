
public class Name {

	public static void main(String[] args) {
		System.out.println("Jaan Malik");
		System.out.println("jmalik01@nyit.edu");
		System.out.println("1279023");

	}

}