
public class Add {

	public static void main(String[] args) {
		int number1 = 5;
		int number2 = 6;
		
		System.out.println(5 + 6);
        int sum = number1 + number2;

        System.out.println("The sum is: " + sum);

	}

}
